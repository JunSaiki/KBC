#include "stdafx.h"
#include "Player.h"


Player::Player()
{
}


Player::~Player()
{
}

void Player::Init(void ) {
}

int Player::GetCondition() {
	return 0;
}

void Player::SetDamage(int damege) {
}

JANKEN Player::Attack() {
	JANKEN JA=GU;
	return JA;
}

