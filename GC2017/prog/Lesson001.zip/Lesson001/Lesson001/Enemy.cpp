#include "stdafx.h"
#include "Enemy.h"


Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

void Enemy::Init() {

}

void Enemy::Update() {
	
}

int Enemy::GetCondition() {

}

void Enemy::SetDamage(int dm) {

}
