#pragma once

bool GameFlag;
